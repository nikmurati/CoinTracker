//
//  CoinCell.swift
//  Coin Tracker
//
//  Created by Rinor Bytyci on 11/12/17.
//  Copyright © 2017 Appbites. All rights reserved.
//

import UIKit

class CoinCell: UITableViewCell {
    
    @IBOutlet weak var imgFotoja: UIImageView!
    
    @IBOutlet weak var lblSymboli: UILabel!
    @IBOutlet weak var lblAlgoritmi: UILabel!
    @IBOutlet weak var lblTotali: UILabel!
    @IBOutlet weak var lblEmri: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    
    
}
