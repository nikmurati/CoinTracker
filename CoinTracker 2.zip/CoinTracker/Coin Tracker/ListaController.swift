//
//  ListaController.swift
//  Coin Tracker
//
//  Created by Rinor Bytyci on 11/12/17.
//  Copyright © 2017 Appbites. All rights reserved.
//

import UIKit
import AlamofireImage
import Alamofire
import SwiftyJSON


//Duhet te jete conform protocoleve per tabele
class ListaController: UIViewController, UITableViewDelegate, UITableViewDataSource{
 
    
   //Krijo IBOutlet tableView nga View
    @IBOutlet weak var tableView: UITableView!
    //var detailcontroller:ListaControllerDelegate!
   
    //Krijo nje varg qe mban te dhena te tipit CoinCellModel
    var tedhenat = [CoinCellModel]()
    //Krijo nje variable slectedCoin te tipit CoinCellModel!
    var selectedCoin:CoinCellModel!
    
    //kjo perdoret per tja derguar Controllerit "DetailsController"
    //me poshte, kur ndodh kalimi nga screen ne screen (prepare for segue)
    
    
    //URL per API qe ka listen me te gjithe coins
    //per me shume detaje : https://www.cryptocompare.com/api/
    let APIURL = "https://min-api.cryptocompare.com/data/all/coinlist"
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
        tableView.delegate = self
        tableView.dataSource = self
        //regjistro delegate dhe datasource per tableview
        
        //regjistro custom cell qe eshte krijuar me NIB name dhe
        //reuse identifier
        tableView.register(UINib.init(nibName: "CoinCell", bundle: nil), forCellReuseIdentifier: "coinCell")
        //Thirr funksionin getDataFromAPI()
      getDataFromAPI()
    }
    
    //Funksioni getDataFromAPI()
    //Perdor alamofire per te thirre APIURL dhe ruan te dhenat
    //ne listen vargun me CoinCellModel
    //Si perfundim, thrret tableView.reloadData()
    func getDataFromAPI(){
        let APIURL = "https://min-api.cryptocompare.com/data/all/coinlist"
        Alamofire.request(APIURL).responseData{(data) in
        if data.result.isSuccess
        {
            let jsonItem = try! JSON(data.result.value)
          //  print()
            
           for (key,tedhenatJSON):(String, JSON) in jsonItem["Data"]{
        //    print (tedhenatJSON["CoinName"])
            self.tedhenat.append(CoinCellModel(coinName: tedhenatJSON["CoinName"].stringValue, coinSymbol: tedhenatJSON["Name"].stringValue , coinAlgo: tedhenatJSON["Algorithm"].stringValue, totalSuppy: tedhenatJSON["TotalCoinSupply"].stringValue, imagePath: tedhenatJSON["ImageUrl"].stringValue))
  
            
            }
            
         self.tableView.reloadData()
        
    }
        }
    }
 

    //Shkruaj dy funksionet e tabeles ketu
    //cellforrowat indexpath dhe numberofrowsinsection
            func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
                return self.tedhenat.count
            }
            func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
                
                let cell = tableView.dequeueReusableCell(withIdentifier: "coinCell") as! CoinCell
              cell.lblEmri.text = self.tedhenat[indexPath.row].coinName
               cell.lblTotali.text = self.tedhenat[indexPath.row].totalSuppy
                cell.lblSymboli.text = self.tedhenat[indexPath.row].coinSymbol
                cell.lblAlgoritmi.text = self.tedhenat[indexPath.row].coinAlgo
                 cell.imgFotoja.af_setImage(withURL: URL(string: self.tedhenat[indexPath.row].imagep())!)
                
               
                return cell
            }
    
    
    //Funksioni didSelectRowAt indexPath merr parane qe eshte klikuar
    //Ruaj Coinin e klikuar tek selectedCoin variabla e deklarurar ne fillim
    //dhe e hap screenin tjeter duke perdore funksionin
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
            let coin  = tedhenat[indexPath.row]
            selectedCoin = coin
            performSegue(withIdentifier: "shfaqDetajet", sender: self)
    }
    
   
 
    //performSeguew(withIdentifier: "EmriILidhjes", sender, self)
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
       
            if segue.identifier == "shfaqDetajet"{
                let detailcontroller = segue.destination as! DetailsController
                detailcontroller.selectedCoin = self.selectedCoin
           
            }
        }
        
    
    //Beje override funksionin prepare(for segue...)
    //nese identifier eshte emri i lidhjes ne Storyboard.
    //controllerit tjeter ja vendosim si selectedCoin, coinin
    //qe e kemi ruajtur me siper

   

}

